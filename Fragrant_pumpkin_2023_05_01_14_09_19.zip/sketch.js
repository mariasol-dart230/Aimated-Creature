let a = -5; 
let b = -10;
let c = -2;
let d = -15;
let e = -7;
let f = -5;
let g = -10;
let h = -2;
let i = -15;
let j = -7;
let k = -5;
let l = -10;
let m = -2;
let n = -15;
let o = -7;
let p = -5;




function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(3, 252, 248);
  fill(255);
  stroke(0);
  strokeWeight(2);
  rect (0, 300, 400, 100);
  ellipse (200, 250, 200, 200);
  ellipse (200, 100, 100, 100);
  fill(105, 66, 4);
  ellipse (300, 200, 100, 10);
  ellipse (100, 200, 100, 10);
  fill (18, 16, 18);
  ellipse (225, 90, 10, 10);
  ellipse (175, 90, 10, 10);
  fill(181, 101, 169);
  ellipse (200, 200, 10, 10);
  ellipse (200, 250, 10, 10);
  ellipse (200, 300, 10, 10);
  fill (252, 152, 3);
  triangle (210, 130, 200, 110, 110, 110);
  fill (255);
  noStroke();
  
  ellipse (50, a, 10, 10);
  a=a+1; 
  if (a>300) {
    a=-5;
    }
  
  ellipse (90, b, 10, 10);
  
  b=b+0.5; 
  
  if (b>300) {
    b=-10;
  }
  
  ellipse (150, c, 10, 10);
  c=c+0.2
  if (c>300) {
    
    c=-2;
  }
  
  
  ellipse (300, d, 10, 10);
  d=d+0.3; 
  if (d>300) {
    a=-15;
    }
  
  
  ellipse (50, e, 10, 10);
  e=e+0.7; 
  if (e>300) {
    e=-7;
    }
  
  ellipse (350, f, 10, 10);
  f=f+1; 
  if (f>300) {
    f=-5;
    }
  
  ellipse (300, g, 10, 10);
  g=g+0.5; 
  if (g>300) {
    g=-10;
    }
  
  ellipse (320, h, 10, 10);
  h=h+0.2; 
  if (h>300) {
    h=-2;
    }
  
  ellipse (30, i, 10, 10);
  i=i+0.3; 
  if (i>300) {
    i=-15;
    }
  
  ellipse (370, j, 10, 10);
  j=j+1; 
  if (j>300) {
    j=-7;
    }
  
  ellipse (20, k, 10, 10);
  k=k+0.5; 
  if (k>300) {
    k=-5;
    }
  
  ellipse (100, l, 10, 10);
  l=l+0.7; 
  if (l>300) {
    l=-10;
    }
  
  ellipse (30, m, 10, 10);
  m=m+0.6; 
  if (m>300) {
    m=-2;
    }
  
  ellipse (370, n, 10, 10);
  n=n+1; 
  if (n>300) {
    n=-15;
    }
  
  ellipse (370, o, 10, 10);
  o=o+0.2; 
  if (o>300) {
    o=-7;
    }
  
  ellipse (230, p, 10, 10);
  p=p+0.5; 
  if (p>300) {
    p=-5;
    }
  
  textSize (25);
  text ("❄", 180, 30);
  text ("❄", 20, 100);
  text ("❄", 90, 150);
  text ("❄", 280, 120);
  text ("❄", 320, 250);
  text ("❄", 70, 270);
  fill (26, 47, 201);
  textStyle(ITALIC);
  textSize (32);
  text ('❄ the snowman ❄', 70, 380);
  
  
}